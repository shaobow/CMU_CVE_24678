Operating system: Windows 10
IDE: PyCharm
Hours to complete: 6hrs

Terminal commands: 
>> python ps3_2.py cheerios.png s
>> python ps3_2.py professor.png s
>> python ps3_2.py gear.png s
>> python ps3_2.py circuit.png s

>> python ps3_2.py cheerios.png c
>> python ps3_2.py professor.png c
>> python ps3_2.py gear.png c
>> python ps3_2.py circuit.png c

Note: 
"s" in the command argument input stands for Sobel filter
"c" in the command argument input stands for Canny edge detector