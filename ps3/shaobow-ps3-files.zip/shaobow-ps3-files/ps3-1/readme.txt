Operating system: Windows 10
IDE: PyCharm
Hours to complete: 4hrs

Terminal commands: 
>> python ps3_1.py golf.png
>> python ps3_1.py pcb.png
>> python ps3_1.py pots.png
>> python ps3_1.py rainbow.png