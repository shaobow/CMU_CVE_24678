Operating system: Windows 10
IDE: PyCharm
Hours to complete: 3hrs

Terminal commands: 
>> python ps4_1.py --d 0
>> python ps4_1.py --d 1
>> python ps4_1.py --d 2
>> python ps4_1.py --d 3

Note: 
"0" in the command argument input stands for "wall"
"1" in the command argument input stands for "door"
"2" in the command argument input stands for "house"
"3" in the command argument input stands for "pittsburgh"
