Operating system: Windows 10
IDE: PyCharm
Hours to complete: 3hrs

Terminal commands: 
python ps2_1.py night-vision.png
python ps2_1.py thermal.png
python ps2_1.py x-ray.png
python ps2_1.py topography.png
python ps2_1.py cracks.png
