Operating system: Windows 10
IDE: PyCharm
Hours to complete: 2hrs

Terminal command: 
python ps1_3.py smiley.jpg
python ps1_3.py carnival.jpg