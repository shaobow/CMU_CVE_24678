Operating system: Windows 10
IDE: PyCharm
Hours to complete: 3hrs

Terminal command: 
python ps1_2.py circuit.png B
python ps1_2.py crack.png D

("B" for emphasize brighter part; "D" for emphasize darker part)