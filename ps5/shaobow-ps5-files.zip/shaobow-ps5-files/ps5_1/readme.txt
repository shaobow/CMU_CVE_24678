Operating system: Windows 10
IDE: PyCharm
Hours to complete: 3hrs

Terminal commands: 
>> python ps5_1.py wall1.png
>> python ps5_1.py wall2.png

Press "S" to save all images
Press "Esc" to exit